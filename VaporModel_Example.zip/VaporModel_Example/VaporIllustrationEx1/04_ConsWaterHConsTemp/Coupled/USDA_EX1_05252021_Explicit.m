% USDA example 1
% constant temperature (may need to low the water content)

clear all
close all
clc

H=50; % unit cm
T=200*24*3600; % the input is "day", but the 
nh=100; % number of spatial nodes
dt_0=1; % unit of second
dt_max=60;

dh=H/nh;
dt=dt_0;
TotalT=0;
epsilon=0.0001;
theta_ini=0.15;
tmpr_ini=25;

% prelim parameters
rho_l=1.000;    % "g cm^-3"
L_0=2270;        % "J g^-1"
c_v=1.864;       % "J g^-1 K-1"
c_l=4.187;       % "J g^-1 K-1"
T_0=25;          % "oC"
theta_s=0.547;

Head=zeros(nh+1,1); % from bottom to top
Temp=zeros(nh+1,1);
Theta=zeros(nh+1,1);

% assume boundary conditions
TLeft=25;
TRight=30;
HLeft=-9.274162934176326e+03;
HRight=-8.570390159801457e+05;

% install the intial condition

SaveThreshold=3600;
TSindex=1;

for i=2:nh+1
    Head(i,1)=FunWrc(theta_ini,tmpr_ini,2);
    Temp(i,1)=tmpr_ini;
    Theta(i,1)=theta_ini;
end
Temp(1,1)=TLeft; Head(1,1)=HLeft;Theta(1,1)=FunWrc(HLeft,TLeft,1);
Temp(nh+1,1)=TRight; Head(nh+1,1)=HRight;Theta(nh+1,1)=FunWrc(HRight,TRight,1);
    
Headt=Head;
Tempt=Temp;
Headtt=Head;
Temptt=Temp;
Headpp=Head;
Temppp=Temp;

% begin the time domain iteration, Total time is the stop citerion
while TotalT<T
    
    
    p=0;
    r=dt/dh/dh;
    Headtt=Head;
    Temptt=Temp;
    
    for i=2:nh
        
        % Water Equation
        % Liquid Flux
        q_liquid_right=r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i+1),Temp(i+1))))*(Head(i+1)-Head(i))...
            +r.*(+1)*abs(sqrt(FunDtl(Head(i),Temp(i)).*FunDtl(Head(i+1),Temp(i+1)))).*(Temp(i+1)-Temp(i));
        q_liquid_left=r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i-1),Temp(i-1))))*(Head(i)-Head(i-1))...
            +r.*(+1)*abs(sqrt(FunDtl(Head(i),Temp(i)).*FunDtl(Head(i-1),Temp(i-1)))).*(Temp(i)-Temp(i-1));
        % Vapor Flux
        q_vapor_right=r.*abs(sqrt(FunDmv(Head(i),Temp(i)).*FunDmv(Head(i+1),Temp(i+1))))*(Head(i+1)-Head(i))...
            +r.*abs(sqrt(FunDtv(Head(i),Temp(i)).*FunDtv(Head(i+1),Temp(i+1)))).*(Temp(i+1)-Temp(i));
        q_vapor_left=r.*abs(sqrt(FunDmv(Head(i),Temp(i)).*FunDmv(Head(i-1),Temp(i-1))))*(Head(i)-Head(i-1))...
            +r.*abs(sqrt(FunDtv(Head(i),Temp(i)).*FunDtv(Head(i-1),Temp(i-1)))).*(Temp(i)-Temp(i-1));

        % Heat Equation
        % Conductive
        q_conduct_right=r.*abs(sqrt(FunLambda_Bulk(Head(i),Temp(i)).*FunLambda_Bulk(Head(i+1),Temp(i+1)))).*(Temp(i+1)-Temp(i));
        q_conduct_left=r.*abs(sqrt(FunLambda_Bulk(Head(i),Temp(i)).*FunLambda_Bulk(Head(i-1),Temp(i-1)))).*(Temp(i)-Temp(i-1));
        % Latent Liquid
        if(q_liquid_right>0)
            q_latent_liq_right=rho_l.*c_l.*(Temp(i+1)-T_0).*q_liquid_right;
        elseif(q_liquid_right<0)
            q_latent_liq_right=rho_l.*c_l.*(Temp(i)-T_0).*q_liquid_right;
        else
            q_latent_liq_right=0;
        end
        if(q_liquid_left>0)
            q_latent_liq_left=rho_l.*c_l.*(Temp(i)-T_0).*q_liquid_right;
        elseif(q_liquid_left<0)
            q_latent_liq_left=rho_l.*c_l.*(Temp(i-1)-T_0).*q_liquid_right;
        else
            q_latent_liq_left=0;
        end
        % Latent Vapor
        if(q_vapor_right>0)
            q_latent_vap_right=rho_l.*(L_0+c_v.*(Temp(i+1)-T_0)).*q_vapor_right;
        elseif(q_vapor_right<0)
            q_latent_vap_right=rho_l.*(L_0+c_v.*(Temp(i)-T_0)).*q_vapor_right;
        else
            q_latent_vap_right=0;
        end
        if(q_vapor_left>0)
            q_latent_vap_left=rho_l.*(L_0+c_v.*(Temp(i)-T_0)).*q_vapor_left;
        elseif(q_vapor_left<0)
            q_latent_vap_left=rho_l.*(L_0+c_v.*(Temp(i-1)-T_0)).*q_vapor_left;
        else
            q_latent_vap_left=0;
        end
        
        % Establish equation system
        A=[FunH1(Head(i),Temp(i)),FunH2(Head(i),Temp(i));
            FunT2(Head(i),Temp(i)),FunT1(Head(i),Temp(i))];
        B=[q_liquid_right+q_vapor_right-q_liquid_left-q_vapor_left;
            q_conduct_right-q_conduct_left+q_latent_liq_right-q_latent_liq_left+q_latent_vap_right-q_latent_vap_left];
        KK=A\B;
        Headtt(i)=min(Head(i)+KK(1),-13.0);
        Temptt(i)=Temp(i)+KK(2);
    end
    
    % embeded BC 
    % BC for water equation zero flux
    % left
 
        % Establish equation system
        A=[1,0;0,1];
        B=[HLeft;TLeft];
        KK=A\B;
        Headtt(1)=min(KK(1),-13.0);
        Temptt(1)=KK(2);
    % right

        % Establish equation system
        A=[1,0;0,1];
        B=[HRight;TRight];
        KK=A\B;
        Headtt(nh+1)=min(KK(1),-13.0);
        Temptt(nh+1)=KK(2);    
    
    while p<5
        p=p+1;
        r=dt/dh/dh;
        Headpp=Headtt;
        Temppp=Temptt;
        Headt=0.5.*(Headtt+Head);
        Tempt=0.5.*(Temptt+Temp);
        
        for i=2:nh
            % Hydraulic Equation
            % Coefficient

            % Water Equation
            % Liquid Flux
            q_liquid_right=r.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1))))*(Headt(i+1)-Headt(i))...
                +r.*(+1)*abs(sqrt(FunDtl(Headt(i),Tempt(i)).*FunDtl(Headt(i+1),Tempt(i+1)))).*(Tempt(i+1)-Tempt(i));
            q_liquid_left=r.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1))))*(Headt(i)-Headt(i-1))...
                +r.*(+1)*abs(sqrt(FunDtl(Headt(i),Tempt(i)).*FunDtl(Headt(i-1),Tempt(i-1)))).*(Tempt(i)-Tempt(i-1));
            % Vapor Flux
            q_vapor_right=r.*abs(sqrt(FunDmv(Headt(i),Tempt(i)).*FunDmv(Headt(i+1),Tempt(i+1))))*(Headt(i+1)-Headt(i))...
                +r.*abs(sqrt(FunDtv(Headt(i),Tempt(i)).*FunDtv(Headt(i+1),Tempt(i+1)))).*(Tempt(i+1)-Tempt(i));
            q_vapor_left=r.*abs(sqrt(FunDmv(Headt(i),Tempt(i)).*FunDmv(Headt(i-1),Tempt(i-1))))*(Headt(i)-Headt(i-1))...
                +r.*abs(sqrt(FunDtv(Headt(i),Tempt(i)).*FunDtv(Headt(i-1),Tempt(i-1)))).*(Tempt(i)-Tempt(i-1));

            % Heat Equation
            % Conductive
            q_conduct_right=r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i+1),Tempt(i+1)))).*(Tempt(i+1)-Tempt(i));
            q_conduct_left=r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i-1),Tempt(i-1)))).*(Tempt(i)-Tempt(i-1));
            % Latent Liquid
            if(q_liquid_right>0)
                q_latent_liq_right=rho_l.*c_l.*(Tempt(i+1)-T_0).*q_liquid_right;
            elseif(q_liquid_right<0)
                q_latent_liq_right=rho_l.*c_l.*(Tempt(i)-T_0).*q_liquid_right;
            else
                q_latent_liq_right=0;
            end
            if(q_liquid_left>0)
                q_latent_liq_left=rho_l.*c_l.*(Tempt(i)-T_0).*q_liquid_right;
            elseif(q_liquid_left<0)
                q_latent_liq_left=rho_l.*c_l.*(Tempt(i-1)-T_0).*q_liquid_right;
            else
                q_latent_liq_left=0;
            end
            % Latent Vapor
            if(q_vapor_right>0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Tempt(i+1)-T_0)).*q_vapor_right;
            elseif(q_vapor_right<0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Tempt(i)-T_0)).*q_vapor_right;
            else
                q_latent_vap_right=0;
            end
            if(q_vapor_left>0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Tempt(i)-T_0)).*q_vapor_left;
            elseif(q_vapor_left<0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Tempt(i-1)-T_0)).*q_vapor_left;
            else
                q_latent_vap_left=0;
            end

            % Establish equation system
            A=[FunH1(Headt(i),Tempt(i)),FunH2(Headt(i),Tempt(i));
                FunT2(Headt(i),Tempt(i)),FunT1(Headt(i),Tempt(i))];
            B=[q_liquid_right+q_vapor_right-q_liquid_left-q_vapor_left;
                q_conduct_right-q_conduct_left+q_latent_liq_right-q_latent_liq_left+q_latent_vap_right-q_latent_vap_left];
            KK=A\B;
            Headtt(i)=min(Head(i)+KK(1),-13.0);
            Temptt(i)=Temp(i)+KK(2);
        
        end
    
        
        % embeded BC 
        % BC for water equation zero flux
        % left

            % Establish equation system
        A=[1,0;0,1];
        B=[HLeft;TLeft];
        KK=A\B;
        Headtt(1)=min(KK(1),-13.0);
        Temptt(1)=KK(2);
        % right

            % Establish equation system
        A=[1,0;0,1];
        B=[HRight;TRight];
        KK=A\B;
        Headtt(nh+1)=min(KK(1),-13.0);
        Temptt(nh+1)=KK(2); 
        
        max1=max(abs(Headtt-Headpp)./max(abs(Headpp)));
        max2=max(abs(Temptt-Temppp)./max(abs(Temppp)));
       
        if (max(max1,max2)<epsilon)
            p=6;
            Head=Headtt;
            Temp=Temptt;
            TotalT=TotalT+dt;
            dt=min(dt_max,dt*1.5);
        end
        
        if p==5
            dt=dt/2;
        end 
       
    end
    
    for i=1:nh+1
        Theta(i,1)=FunWrc(Head(i),Temp(i),1);
    end
    
    if TotalT>SaveThreshold
        ThetaSave(:,TSindex)=Theta;
        HeadSave(:,TSindex)=Head;
        TmprSave(:,TSindex)=Temp;
        SaveThreshold=SaveThreshold+3600;
        TSindex=TSindex+1;
    end
 
end

xlswrite('..\SimuResCoupled.xlsx',ThetaSave,'theta');
xlswrite('..\SimuResCoupled.xlsx',HeadSave,'head');
xlswrite('..\SimuResCoupled.xlsx',TmprSave,'temp');
