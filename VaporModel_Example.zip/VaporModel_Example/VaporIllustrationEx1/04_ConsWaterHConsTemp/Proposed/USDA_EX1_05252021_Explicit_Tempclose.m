% USDA example 1
% constant temperature (may need to low the water content)

clear all
close all
clc

H=50; % unit cm
T=200*24*3600; % the input is "day", but the 
nh=100; % number of spatial nodes
dt_0=1; % unit of second
dt_max=60;

L_0=2270;        % "J g^-1"
c_v=1.864;      % "J g^-1 K-1"
c_l=4.187;      %"J g^-1 K-1"
theta_s=0.547;
rho_l=1.000;    % g cm^-3
T_0=25;          % oC

dh=H/nh;
dt=dt_0;
TotalT=0;
epsilon=0.0001;
theta_ini=0.15;
tmpr_ini=25;

Head=zeros(nh+1,1); % from bottom to top
Temp=zeros(nh+1,1);
Theta=zeros(nh+1,1);

% assume boundary conditions
TLeft=25;
TRight=30;
HLeft=-9.274162934176326e+03;
HRight=-8.570390159801457e+05;

% install the intial condition

SaveThreshold=3600;
TSindex=1;

for i=2:nh
    Head(i,1)=FunWrc(theta_ini,tmpr_ini,2);
    Temp(i,1)=tmpr_ini;
    Theta(i,1)=theta_ini;
end
Temp(1,1)=TLeft; Head(1,1)=HLeft;Theta(1,1)=FunWrc(HLeft,TLeft,1);
Temp(nh+1,1)=TRight; Head(nh+1,1)=HRight;Theta(nh+1,1)=FunWrc(HRight,TRight,1);


% begin the time domain iteration, Total time is the stop citerion
while TotalT<T
% ---------------------------------------------------------------------------------------------------    
% firs the water equation     
    
    p=0;
    A=sparse(nh+1,nh+1);
    B=zeros(nh+1,1);
    r=dt/dh/dh;
    
    for i=2:nh
        
        % Hydraulic Equation
        % Coefficient
        A(i,i-1)=-r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i-1),Temp(i-1))));
        A(i,i+1)=-r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i+1),Temp(i+1))));
        A(i,i)=r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i-1),Temp(i-1))))...
            +r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i+1),Temp(i+1))))...
            +FunWaCapa(Head(i),Temp(i),1);
        % RHS vector
%        B(i,1)=FunWaCapa(Head(i),Temp(i),1).*Head(i);
        B(i,1)=FunWaCapa(Head(i),Temp(i),1).*Head(i)...
            +r.*(+1)*abs(sqrt(FunDtl(Head(i),Temp(i)).*FunDtl(Head(i+1),Temp(i+1)))).*(Temp(i+1)-Temp(i))...
            -r.*(+1)*abs(sqrt(FunDtl(Head(i),Temp(i)).*FunDtl(Head(i-1),Temp(i-1)))).*(Temp(i)-Temp(i-1));
    end
    
    % embeded BC 

    A(1,1)=1;
    A(nh+1,nh+1)=1;
    B(1,1)=HLeft;
    B(nh+1,1)=HRight;
    % solve the equation
    KK=A\B;
    
    Headtt=KK;
    for i=1:nh+1
        if Headtt(i)>-13.0
            Headtt(i)=-13.0;
        end
    end
    WaterFail=1;
    
    while p<5
        p=p+1;
        A=sparse(nh+1,nh+1);
        B=zeros(nh+1,1);
        r=dt/dh/dh;
        Headt=Headtt;
        
        for i=2:nh
            % Hydraulic Equation
            % Coefficient
            A(i,i-1)=-r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1))));
            A(i,i+1)=-r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1))));
            A(i,i)=r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1))))...
                +r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1))))...
                +FunWaCapa(Headt(i),Temp(i),1);
            % RHS vector
%            B(i,1)=FunWaCapa(Headt(i),Temp(i),1).*Head(i);
            B(i,1)=FunWaCapa(Headt(i),Temp(i),1).*Head(i)...
             +r.*(+1)*abs(sqrt(FunDtl(Headt(i),Temp(i)).*FunDtl(Headt(i+1),Temp(i+1)))).*(Temp(i+1)-Temp(i))...
             -r.*(+1)*abs(sqrt(FunDtl(Headt(i),Temp(i)).*FunDtl(Headt(i-1),Temp(i-1)))).*(Temp(i)-Temp(i-1));
        end
    
        % embeded BC 
        A(1,1)=1;
        A(nh+1,nh+1)=1;
        B(1,1)=HLeft;
        B(nh+1,1)=HRight;
    
        % solve the equation
        KK=A\B;
       
        Headtt=KK;
        for i=1:nh+1
          if Headtt(i)>-13.0
             Headtt(i)=-13.0;
          end
        end
        
        max1=max(abs(Headtt-Headt)./max(abs(Headt)));
        max2=0.0;
       
        if (max(max1,max2)<epsilon)
            p=6;
            Headt=Headtt;
            WaterFail=0;
                     
        end
        
        if p==5
            dt=dt/2;
            WaterFail=1;
        end 
       
    end
    
% ---------------------------------------------------------------------------------------------    
% second the heat equation
    
    if WaterFail==0

        p=0;
        A=sparse(nh+1,nh+1);
        B=zeros(nh+1,1);
        r=dt/dh/dh;

        for i=2:nh

            % Heat Equation
            % Coefficient
            A(i,i-1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i-1),Temp(i-1))));
            A(i,i+1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i+1),Temp(i+1))));
            A(i,i)=r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i-1),Temp(i-1))))...
                +r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i+1),Temp(i+1))))...
                +FunCs(Headt(i),Temp(i));

            if Headt(i+1)>Headt(i)
               A(i,i+1)=A(i,i+1)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1)))).*(Headt(i+1)-Headt(i));
            else
               A(i,i)=A(i,i)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1)))).*(Headt(i+1)-Headt(i));
            end

            if Headt(i)>Headt(i-1)
               A(i,i)=A(i,i)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1)))).*(Headt(i)-Headt(i-1));
            elseif Headt(i)<Headt(i-1)
               A(i,i-1)=A(i,i-1)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1)))).*(Headt(i)-Headt(i-1)); 
            end
        
            % RHS vector
            B(i,1)=FunCs(Headt(i),Temp(i)).*Temp(i)...
                -r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1)))).*(Headt(i+1)-Headt(i)).*T_0...
                +r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1)))).*(Headt(i)-Headt(i-1)).*T_0;

        end

        % embeded BC 
        % left
        A(1,1)=1;
        B(1,1)=TLeft;

        % right
        A(nh+1,nh+1)=1;   
        B(nh+1,1)=TRight;

        % solve the equation
        KK=A\B;

        Temptt=KK;
        HeatFail=1;
        
        while p<5
            p=p+1;
            A=sparse(nh+1,nh+1);
            B=zeros(nh+1,1);
            r=dt/dh/dh;
            Tempt=Temptt;

            for i=2:nh
                % Heat Equation
                % Coefficient
                A(i,i-1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i-1),Tempt(i-1))));
                A(i,i+1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i+1),Tempt(i+1))));
                A(i,i)=r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i-1),Tempt(i-1))))...
                    +r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i+1),Tempt(i+1))))...
                    +FunCs(Headt(i),Tempt(i));
                % RHS vector
                
                if Headt(i+1)>Headt(i)
                   A(i,i+1)=A(i,i+1)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1)))).*(Headt(i+1)-Headt(i));
                elseif Headt(i+1)<Headt(i)
                   A(i,i)=A(i,i)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1)))).*(Headt(i+1)-Headt(i));
                end

                if Headt(i)>Headt(i-1)
                   A(i,i)=A(i,i)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1)))).*(Headt(i)-Headt(i-1));
                elseif Headt(i)<Headt(i-1)
                   A(i,i-1)=A(i,i-1)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1)))).*(Headt(i)-Headt(i-1)); 
                end

                B(i,1)=FunCs(Headt(i),Tempt(i)).*Temp(i)...
                    -r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1)))).*(Headt(i+1)-Headt(i)).*T_0...
                    +r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1)))).*(Headt(i)-Headt(i-1)).*T_0;

            end

            % embeded BC 
            % left
            A(1,1)=1;
            B(1,1)=TLeft;

            % up
            A(nh+1,nh+1)=1;   
            B(nh+1,1)=TRight;

            % solve the equation
            KK=A\B;

            Temptt=KK;

            max1=0.0;
            max2=max(abs(Temptt-Tempt)./max(abs(Tempt)));

            if (max(max1,max2)<epsilon)
                p=6;
                Tempt=Temptt;
                HeatFail=0;
            end

            if p==5
                dt=dt/2;
                HeatFail=1;
            end 

        end
    end
 
% ---------------------------------------------------------------------------------------------    
% third the vapor equation   
 
    if WaterFail==0&&HeatFail==0
        p=0;
        Headss=Headt;
        Tempss=Tempt;
        Headpp=Headt;
        Temppp=Tempt;		
        r=dt/dh/dh;

        
        for i=2:nh
            % Hydraulic Equation
            % Coefficient

            % Water Equation
            % Vapor Flux
            q_vapor_right=r.*abs(sqrt(FunDmv(Headt(i),Tempt(i)).*FunDmv(Headt(i+1),Tempt(i+1))))*(Headt(i+1)-Headt(i))...
                +r.*abs(sqrt(FunDtv(Headt(i),Tempt(i)).*FunDtv(Headt(i+1),Tempt(i+1)))).*(Tempt(i+1)-Tempt(i));
            q_vapor_left=r.*abs(sqrt(FunDmv(Headt(i),Tempt(i)).*FunDmv(Headt(i-1),Tempt(i-1))))*(Headt(i)-Headt(i-1))...
                +r.*abs(sqrt(FunDtv(Headt(i),Tempt(i)).*FunDtv(Headt(i-1),Tempt(i-1)))).*(Tempt(i)-Tempt(i-1));

            % Heat Equation
            % Latent Vapor
            if(q_vapor_right>0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Tempt(i+1)-T_0)).*q_vapor_right;
            elseif(q_vapor_right<0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Tempt(i)-T_0)).*q_vapor_right;
            else
                q_latent_vap_right=0;
            end
            if(q_vapor_left>0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Tempt(i)-T_0)).*q_vapor_left;
            elseif(q_vapor_left<0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Tempt(i-1)-T_0)).*q_vapor_left;
            else
                q_latent_vap_left=0;
            end

            % Establish equation system
            A=[FunH1(Headt(i),Tempt(i)),FunH2(Headt(i),Tempt(i));
                FunT2(Headt(i),Tempt(i)),FunT1(Headt(i),Tempt(i))];
            B=[q_vapor_right-q_vapor_left;
                q_latent_vap_right-q_latent_vap_left];
            KK=A\B;
            Headss(i)=min(Headt(i)+KK(1),-13.0);
            Tempss(i)=Tempt(i)+KK(2);     
        end
        % embeded BC 
        % BC for water equation zero flux
        % left
            % Water Equation
            % Vapor Flux
            q_vapor_right=r.*abs(sqrt(FunDmv(Headt(1),Tempt(1)).*FunDmv(Headt(2),Tempt(2))))*(Headt(2)-Headt(1))...
                +r.*abs(sqrt(FunDtv(Headt(1),Tempt(1)).*FunDtv(Headt(2),Tempt(2)))).*(Tempt(2)-Tempt(1));
            q_vapor_left=0;
            % Heat Equation
            % Latent Vapor
            if(q_vapor_right>0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Tempt(2)-T_0)).*q_vapor_right;
            elseif(q_vapor_right<0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Tempt(1)-T_0)).*q_vapor_right;
            else
                q_latent_vap_right=0;
            end
            q_latent_vap_left=0;

            % Establish equation system
            A=[FunH1(Headt(1),Tempt(1)),FunH2(Headt(1),Tempt(1));
                FunT2(Headt(1),Tempt(1)),FunT1(Headt(1),Tempt(1))];
            B=[q_vapor_right-q_vapor_left;
                q_latent_vap_right-q_latent_vap_left];
            KK=A\B;
            Headss(1)=min(Headt(1)+KK(1),-13.0);
            Tempss(1)=Tempt(1)+KK(2);
        % right
            % Water Equation
            % Vapor Flux
            q_vapor_right=0;
            q_vapor_left=r.*abs(sqrt(FunDmv(Headt(nh),Tempt(nh)).*FunDmv(Headt(nh+1),Tempt(nh+1))))*(Headt(nh+1)-Headt(nh))...
                +r.*abs(sqrt(FunDtv(Headt(nh),Tempt(nh)).*FunDtv(Headt(nh+1),Tempt(nh+1)))).*(Tempt(nh+1)-Tempt(nh));
            
            % Heat Equation
            % Latent Vapor
            q_latent_vap_right=0;
            if(q_vapor_left>0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Tempt(nh+1)-T_0)).*q_vapor_left;
            elseif(q_vapor_left<0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Tempt(nh)-T_0)).*q_vapor_left;
            else
                q_latent_vap_left=0;
            end

            % Establish equation system
            A=[FunH1(Headt(nh+1),Tempt(nh+1)),FunH2(Headt(nh+1),Tempt(nh+1));
                FunT2(Headt(nh+1),Tempt(nh+1)),FunT1(Headt(nh+1),Tempt(nh+1))];
            B=[q_vapor_right-q_vapor_left;
                q_latent_vap_right-q_latent_vap_left];
            KK=A\B;
            Headss(nh+1)=min(Headt(nh+1)+KK(1),-13.0);
            Tempss(nh+1)=Tempt(nh+1)+KK(2);        

        while p<5
            p=p+1;
            r=dt/dh/dh;
			
            Headpp=Headss;
            Temppp=Tempss; 
            Heads=0.5.*(Headss+Headt);
            Temps=0.5.*(Tempss+Tempt);

            for i=2:nh
                % Hydraulic Equation
                % Coefficient

                % Water Equation
                % Vapor Flux
                q_vapor_right=r.*abs(sqrt(FunDmv(Heads(i),Temps(i)).*FunDmv(Heads(i+1),Temps(i+1))))*(Heads(i+1)-Heads(i))...
                    +r.*abs(sqrt(FunDtv(Heads(i),Temps(i)).*FunDtv(Heads(i+1),Temps(i+1)))).*(Temps(i+1)-Temps(i));
                q_vapor_left=r.*abs(sqrt(FunDmv(Heads(i),Temps(i)).*FunDmv(Heads(i-1),Temps(i-1))))*(Heads(i)-Heads(i-1))...
                    +r.*abs(sqrt(FunDtv(Heads(i),Temps(i)).*FunDtv(Heads(i-1),Temps(i-1)))).*(Temps(i)-Temps(i-1));

                % Heat Equation
                % Latent Vapor
                if(q_vapor_right>0)
                    q_latent_vap_right=rho_l.*(L_0+c_v.*(Temps(i+1)-T_0)).*q_vapor_right;
                elseif(q_vapor_right<0)
                    q_latent_vap_right=rho_l.*(L_0+c_v.*(Temps(i)-T_0)).*q_vapor_right;
                else
                    q_latent_vap_right=0;
                end
                if(q_vapor_left>0)
                    q_latent_vap_left=rho_l.*(L_0+c_v.*(Temps(i)-T_0)).*q_vapor_left;
                elseif(q_vapor_left<0)
                    q_latent_vap_left=rho_l.*(L_0+c_v.*(Temps(i-1)-T_0)).*q_vapor_left;
                else
                    q_latent_vap_left=0;
                end

                % Establish equation system
                A=[FunH1(Heads(i),Temps(i)),FunH2(Heads(i),Temps(i));
                    FunT2(Heads(i),Temps(i)),FunT1(Heads(i),Temps(i))];
                B=[q_vapor_right-q_vapor_left;
                    q_latent_vap_right-q_latent_vap_left];
                KK=A\B;
                Headss(i)=min(Headt(i)+KK(1),-13.0);
                Tempss(i)=Tempt(i)+KK(2);     
            end

        % embeded BC 
        % BC for water equation zero flux
        % left
            % Water Equation
            % Vapor Flux
            q_vapor_right=r.*abs(sqrt(FunDmv(Heads(1),Temps(1)).*FunDmv(Heads(2),Temps(2))))*(Heads(2)-Heads(1))...
                +r.*abs(sqrt(FunDtv(Heads(1),Temps(1)).*FunDtv(Heads(2),Temps(2)))).*(Temps(2)-Temps(1));
            q_vapor_left=0;
            % Heat Equation
            % Latent Vapor
            if(q_vapor_right>0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Temps(2)-T_0)).*q_vapor_right;
            elseif(q_vapor_right<0)
                q_latent_vap_right=rho_l.*(L_0+c_v.*(Temps(1)-T_0)).*q_vapor_right;
            else
                q_latent_vap_right=0;
            end
            q_latent_vap_left=0;

            % Establish equation system
            A=[FunH1(Heads(1),Temps(1)),FunH2(Heads(1),Temps(1));
                FunT2(Heads(1),Temps(1)),FunT1(Heads(1),Temps(1))];
            B=[q_vapor_right-q_vapor_left;
                q_latent_vap_right-q_latent_vap_left];
            KK=A\B;
            Headss(1)=min(Headt(1)+KK(1),-13.0);
            Tempss(1)=Tempt(1)+KK(2);
        % right
            % Water Equation
            % Vapor Flux
            q_vapor_right=0;
            q_vapor_left=r.*abs(sqrt(FunDmv(Heads(nh),Temps(nh)).*FunDmv(Heads(nh+1),Temps(nh+1))))*(Heads(nh+1)-Heads(nh))...
                +r.*abs(sqrt(FunDtv(Heads(nh),Temps(nh)).*FunDtv(Heads(nh+1),Temps(nh+1)))).*(Temps(nh+1)-Temps(nh));
            
            % Heat Equation
            % Latent Vapor
            q_latent_vap_right=0;
            if(q_vapor_left>0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Temps(nh+1)-T_0)).*q_vapor_left;
            elseif(q_vapor_left<0)
                q_latent_vap_left=rho_l.*(L_0+c_v.*(Temps(nh)-T_0)).*q_vapor_left;
            else
                q_latent_vap_left=0;
            end

            % Establish equation system
            A=[FunH1(Heads(nh+1),Temps(nh+1)),FunH2(Heads(nh+1),Temps(nh+1));
                FunT2(Heads(nh+1),Temps(nh+1)),FunT1(Heads(nh+1),Temps(nh+1))];
            B=[q_vapor_right-q_vapor_left;
                q_latent_vap_right-q_latent_vap_left];
            KK=A\B;
            Headss(nh+1)=min(Headt(nh+1)+KK(1),-13.0);
            Tempss(nh+1)=Tempt(nh+1)+KK(2);   
            
            
            max1=max(abs(Headss-Headpp)./max(abs(Headpp)));
            max2=max(abs(Tempss-Temppp)./max(abs(Temppp)));

            if (max(max1,max2)<epsilon)
                p=6;
                Head=Headss;
                Temp=Tempss;
                TotalT=TotalT+dt;
                dt=min(dt_max,dt*1.5);
                
            end

            if p==5
                dt=dt/2;
            end 

        end
        
    end
    
      
    for i=1:nh+1
        Theta(i,1)=FunWrc(Head(i),Temp(i),1);
    end
    
    if TotalT>SaveThreshold
        ThetaSave(:,TSindex)=Theta;
        HeadSave(:,TSindex)=Head;
        TmprSave(:,TSindex)=Temp;
        SaveThreshold=SaveThreshold+3600;
        TSindex=TSindex+1;
    end
    
end

xlswrite('..\SimuResPropose.xlsx',ThetaSave,'theta');
xlswrite('..\SimuResPropose.xlsx',HeadSave,'head');
xlswrite('..\SimuResPropose.xlsx',TmprSave,'temp');

