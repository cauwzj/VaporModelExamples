
cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\04_ConsWaterHConsTemp\Coupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\04_ConsWaterHConsTemp\Proposed'
run('USDA_EX1_05252021_Explicit_Tempclose.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\04_ConsWaterHConsTemp\SemiCoupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\04_ConsWaterHConsTemp\Trivial'
run('USDA_EX1_05252021.m')