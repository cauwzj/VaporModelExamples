
cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\02_ZeroWaterConsHeatF\Coupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\02_ZeroWaterConsHeatF\Proposed'
run('USDA_EX1_05252021_Explicit_Tempclose.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\02_ZeroWaterConsHeatF\SemiCoupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx1\02_ZeroWaterConsHeatF\Trivial'
run('USDA_EX1_05252021.m')