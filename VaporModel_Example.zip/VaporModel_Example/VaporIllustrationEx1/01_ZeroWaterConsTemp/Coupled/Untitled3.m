clear all
clc
format long e

h=[-1000,-100,-50];
T=[20,25,30];
theta=FunWrc(h,T,1);

FunDtl(h,T)