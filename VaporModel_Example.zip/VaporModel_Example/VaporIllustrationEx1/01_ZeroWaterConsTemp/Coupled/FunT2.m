
% Thermal_2
% we defined here as T2
% The unit is "J cm^-3 cm^-1"
% T2 is bot as same as the coefficient of the pthetapt, but we change it to
% pPhi_mpt by multipling with water capacity

function y=FunT2(h,T)

% soil properties
theta_s=0.547;
rho_w=1.000; %"g cm^-3"

% prelim parameters
L0=2270; % "J g^-1"
cv=1.864; % "J g^-1 K-1"
cl=4.187; %"J g^-1 K-1"
T0=25; % "oC"

% W (J g^-1) differential heat of wetting
W=0.00462;

% find water content
theta=FunWrc(h,T,1);
theta_a=theta_s-theta;

% potential-temperature correction (ask Horton where the equation [22] Heitman should applied)
ht=h;
Tt=T+273.15;

% calculate necessary quantities
rho_vs=1.0e-6.*exp(19.84-4975.9./Tt);                       % "g cm^-3"
HR=exp(2.1238e-04.*ht./Tt);
prho_vpPhi_m=rho_vs.*HR.*2.1238e-04./Tt;                    % "g cm^-3 cm^-1"
rho_v=rho_vs.*HR;

% finial calculation

y=(L0+cv.*(T-T0)).*theta_a.*prho_vpPhi_m+(cl.*rho_w.*(T-T0)-rho_w.*W-cv.*rho_v.*(T-T0)-L0.*rho_v).*FunWaCapa(h,T,1);



