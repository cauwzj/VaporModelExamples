% The coefficients of pthetapt in Water equation [19] Nassar 
% we defined here as H4
% The unit is "m^2 s^-1 K^-1"
% H4 is the same as the coefficient for gradient of T, i.e. Hydraulic_4

function y=FunH4(h,T)
y=FunDtl(h,T)+FunDtv(h,T);
