% The diffusivity of (conductivity of vapour due to temperature or potential)
% For Dmv, in unit of "cm/s"
% refer to Nassar and Horton 1997 and Heitman 2008


function y=FunDmv(h,T)


theta_s=0.547;             % soil properties
theta=FunWrc(h,T,1);       % from potential to water content
phi=theta_s;               % prelim quantities
rho_l=1.000;               % liquid water density g/m^3

% potential-temperature correction
ht=h;
Tt=T+273.15;
    
%D=2.3500e-05.*real((Tt./273.15).^1.75);  % m^2/s
D=0.23500.*abs((Tt./273.15).^1.75);      % cm^2/s
Omega=abs((phi-theta).^(0.667));
theta_a=phi-theta;

% water vapour properties
rho_s=1.0e-6.*exp(19.84-4975.9./Tt);    % g/cm^3
HR=exp(2.1238e-04.*ht./Tt);
pHRph=HR.*2.1238e-04./Tt;               % partial HR partial ht, unit in /cm

% calculate Dtv
y=D.*Omega.*theta_a.*rho_s.*pHRph./rho_l;



