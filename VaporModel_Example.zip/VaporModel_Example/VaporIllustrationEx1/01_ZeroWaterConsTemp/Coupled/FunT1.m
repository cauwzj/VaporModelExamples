
% Thermal_1
% we defined here as T1
% The unit is "J cm^-3 K^-1"
% T1 is the same as the coefficient of the pTpt

function y=FunT1(h,T)

% soil properties
theta_s=0.547;

% prelim parameters
L0=2270; % "J g^-1"
cv=1.864; % "J g^-1 K-1"
T0=25; % "oC"
beta=2.09e-3; % (K^-1)

% find water content
theta=FunWrc(h,T,1);
theta_a=theta_s-theta;

% potential-temperature correction (ask Horton where the equation [22] Heitman should applied)
ht=h;
Tt=T+273.15;

% calculate necessary quantities
% rho_s=exp(19.84-4975.9./(T+273.5))./1000; %"Kg m^-3"
% HR=exp(9.81.*0.018.*ht./8.3145./(T+273.15));

rho_s=1.0e-6.*exp(19.84-4975.9./Tt);    % g/cm^3
HR=exp(2.1238e-04.*ht./Tt);

prho_spT=rho_s.*4975.9./(Tt.^2);

%{
there are some old code taking into accout of \partial h\partial t,
including the change of h with respect to t

    % calculate the change of potential v.s the change of temperature (ASK Horton)
    % first reduce the potential to reference value
    h0=h.*exp(beta.*(T-T0));
    pPhi_mpT=-beta.*h0.*exp(-beta.*(T-T0));

    pHRpT=HR.*(9.81.*0.018.*pPhi_mpT./8.3145./(T+273.15)-9.81.*0.018.*ht./8.3145./((T+273.15).^2));
%}

pHRpT=-HR.*2.1238e-04.*ht./(Tt.^2);

% finially the partial derivaitve part.
prho_vpT=rho_s.*pHRpT+prho_spT.*HR;

% finial calculation
y=FunCs(h,T)+(L0+cv.*(T-T0)).*theta_a.*prho_vpT;
