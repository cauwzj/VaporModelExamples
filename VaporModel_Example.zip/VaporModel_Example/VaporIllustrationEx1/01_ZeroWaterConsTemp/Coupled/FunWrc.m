% The water retential curve VWC ~ water potential (<0)
% For water potential, uint "cm"
% mode 1: potention to VWC
% mode 2: VWC to potential
% refer to Nassar and Horton 1997 and Heitman 2008

function y=FunWrc(input,T,mode)

% soil properties
theta_s=0.547;
b=6.53;

% prelim parameters
Phi_e=-13.0; % (cm)
T0=25; beta=2.09e-3;

if mode==1
    h=min(input,-13.0);
    h=max(h,-3.0e10);
%    ht=h.*exp(beta.*(T-T0));
    ht=h;
    y=abs((ht./Phi_e).^(-1./b)).*theta_s;
elseif mode==2
    theta=input;
    y=Phi_e.*abs((theta./theta_s).^(-b));
%    y=y.*exp(-beta.*(T-T0));
    y=max(y,-5.0e9);
    y=min(y,-13.0);
end