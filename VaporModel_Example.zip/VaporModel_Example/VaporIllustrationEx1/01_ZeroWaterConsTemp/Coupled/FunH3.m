% The coefficients of pthetapt in Water equation [19] Nassar 
% we defined here as H3
% The unit is "m s^-1"
% H3 is the same as the coefficient for gradient of \Phi_m, i.e. Hydraulic_3

function y=FunH3(h,T)
y=FunKml(h,T)+FunDmv(h,T);
