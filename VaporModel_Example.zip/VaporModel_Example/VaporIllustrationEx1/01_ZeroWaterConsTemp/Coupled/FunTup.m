% The upper BC of temperature, unit oC
% based on Campbell and Norman, 1998

function y=FunTup(t)

T_ave=25;
A=20;
omega=2*pi/(3600*24);

% begin calculaton
y=T_ave+A*sin(omega*(t-8*3600));
