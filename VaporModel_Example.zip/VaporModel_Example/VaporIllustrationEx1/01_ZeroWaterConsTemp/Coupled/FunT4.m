
% Thermal_4
% we defined here as T4
% The unit is "J cm^-3 s^-1 * cm"
% T4 is not as same as the coefficient of the for K3 in the paper, but all
% the term related to pPhi_mpz

function y=FunT4(h,T)

% prelim parameters
L0=2270;        % "J g^-1"
c_v=1.864;      % "J g^-1 K-1"
c_l=4.187;      %"J g^-1 K-1"
rho_l=1.000;    % g cm^-3
T0=25;          % oC

% begin calculation fo K3 in the equation
K3=rho_l.*(L0-(c_l-c_v).*(T-T0)).*FunDmv(h,T);

% begin calculation
y=K3+c_l.*rho_l.*(T-T0).*(FunDmv(h,T)+FunKml(h,T));