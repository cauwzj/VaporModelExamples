
% Thermal_3 
% we defined here as T3
% The unit is "J K^-1 cm^-1 s^-1"
% T3 is not as same as the coefficient of the for K3 in the paper, but all
% the term related to pTpz

function y=FunT3(h,T)

% prelim parameters
c_l=4.187; %"J g^-1 K-1"
rho_l=1.000; % g cm^-3
T0=25; % oC

% begin calculation

y=FunLambda(h,T)+c_l.*rho_l.*(T-T0).*(FunDtv(h,T)+FunDtl(h,T));