clear all
close all
clc

ThetaC=xlsread('SimuResCoupled.xlsx','theta');
TempC=xlsread('SimuResCoupled.xlsx','temp');

ThetaP=xlsread('SimuResPropose.xlsx','theta');
TempP=xlsread('SimuResPropose.xlsx','temp');

ThetaT=xlsread('SimuResTrivial.xlsx','theta');
TempT=xlsread('SimuResTrivial.xlsx','temp');

ThetaS=xlsread('SimuResSemiCoupled.xlsx','theta');
TempS=xlsread('SimuResSemiCoupled.xlsx','temp');

% figure(1)
% hold on
% for i=1:100:4800
%     plot([0:0.5:50],ThetaC(:,i),'k')
% end
% plot([0:0.5:50],ThetaC(:,1),'r','linewidth',2)
% plot([0:0.5:50],ThetaC(:,4800),'r','linewidth',2)
% set(gca,'fontsize',16)
% axis([0,50,0.08,0.23])
% box on 
% 
% figure(2)
% hold on
% for i=1:100:4800
%     plot([0:0.5:50],TempC(:,i),'k')
% end
% plot([0:0.5:50],TempC(:,1),'r','linewidth',2)
% plot([0:0.5:50],TempC(:,4800),'r','linewidth',2)
% set(gca,'fontsize',16)
% axis([0,50,20,30])
% box on 
% % 
% 
% figure(3)
% hold on
% for i=1:100:4800
%     plot([0:2.5:50],ThetaP(:,i),'k')
% end
% plot([0:2.5:50],ThetaP(:,1),'r','linewidth',2)
% plot([0:2.5:50],ThetaP(:,4800),'r','linewidth',2)
% set(gca,'fontsize',16)
% axis([0,50,0.08,0.23])
% box on 
% 
% figure(4)
% hold on
% for i=1:100:4800
%     plot([0:2.5:50],TempP(:,i),'k')
% end
% plot([0:2.5:50],TempP(:,1),'r','linewidth',2)
% plot([0:2.5:50],TempP(:,4800),'r','linewidth',2)
% set(gca,'fontsize',16)
% axis([0,50,20,30])
% box on 
% 
% figure(5)
% hold on
% for i=1:100:4800
%     plot([0:2.5:50],ThetaT(:,i),'k')
% end
% plot([0:2.5:50],ThetaT(:,1),'r','linewidth',2)
% plot([0:2.5:50],ThetaT(:,4800),'r','linewidth',2)
% set(gca,'fontsize',16)
% axis([0,50,0.08,0.23])
% box on 
% 
% figure(6)
% hold on
% for i=1:100:4800
%     plot([0:2.5:50],TempT(:,i),'k')
% end
% plot([0:2.5:50],TempT(:,1),'r','linewidth',2)
% plot([0:2.5:50],TempT(:,4800),'r','linewidth',2)
% set(gca,'fontsize',16)
% axis([0,50,20,30])
% box on


% figure(7)
% x0=10;
% y0=10;
% width=1000;
% height=800;
% set(gcf,'position',[x0,y0,width,height])
% 
% errorPtheta=zeros(4800,1);
% errorPtemp=zeros(4800,1);
% errorTtheta=zeros(4800,1);
% errorTtemp=zeros(4800,1);
% errorStheta=zeros(4800,1);
% errorStemp=zeros(4800,1);
% for i=1:4800
%     errorTtheta(i)=norm(ThetaC(:,i)-ThetaT(:,i),1)/norm(ThetaC(:,i),1);
%     errorTtemp(i)=norm(TempC(:,i)-TempT(:,i),1)/norm(TempC(:,i),1);
%     errorPtheta(i)=norm(ThetaC(:,i)-ThetaP(:,i),1)/norm(ThetaC(:,i),1);
%     errorPtemp(i)=norm(TempC(:,i)-TempP(:,i),1)/norm(TempC(:,i),1);
%     errorStheta(i)=norm(ThetaC(:,i)-ThetaS(:,i),1)/norm(ThetaC(:,i),1);
%     errorStemp(i)=norm(TempC(:,i)-TempS(:,i),1)/norm(ThetaC(:,i),1);
% end
% hold on
% plot([1:4800],errorTtheta,'k--','linewidth',1.5)
% plot([1:4800],errorPtheta,'k','linewidth',1.5)
% plot([1:4800],errorStheta,'k:','linewidth',1.5)
% plot([1:4800],errorTtemp,'r--','linewidth',1.5)
% plot([1:4800],errorPtemp,'r','linewidth',1.5)
% plot([1:4800],errorStemp,'r:','linewidth',1.5)
% legend('water content M_{I}','water content M_{II}','water content M_{R}','temperature M_{I}','temperature M_{II}','temperature M_{R}')
% ylabel('RME with respect to M_{F}')
% xlabel('Time (h)')
% set(gca,'fontname','Times New Roman','fontsize',24)
% set(get(gca,'xlabel'),'fontname','Times New Roman','fontsize',24)
% set(get(gca,'ylabel'),'fontname','Times New Roman','fontsize',24)
% yticks([0:0.01:0.1])
% axis([0,4800,0,0.1])
% box on
% 
% figure(9)
% x0=10;
% y0=10;
% width=400;
% height=300;
% set(gcf,'position',[x0,y0,width,height])
% hold on
% plot([4400:4800],errorPtheta(4400:4800),'k','linewidth',1.5)
% plot([4400:4800],errorStheta(4400:4800),'k:','linewidth',1.5)
% plot([4400:4800],errorPtemp(4400:4800),'r','linewidth',1.5)
% plot([4400:4800],errorStemp(4400:4800),'r:','linewidth',1.5)
% set(gca,'fontname','Times New Roman','fontsize',20)
% set(get(gca,'xlabel'),'fontname','Times New Roman','fontsize',20)
% set(get(gca,'ylabel'),'fontname','Times New Roman','fontsize',20)
% axis([4400,4800,0,0.0004])
% box on

% figure(8)
% errorPtheta=zeros(4800,1);
% errorPtemp=zeros(4800,1);
% errorStheta=zeros(4800,1);
% errorStemp=zeros(4800,1);
% for i=1:4800
%     errorPtheta(i)=mean(ThetaP(:,i)-ThetaC(:,i))/norm(ThetaC(:,i));
%     errorPtemp(i)=mean(TempP(:,i)-TempC(:,i))/norm(TempC(:,i));
%     errorStheta(i)=mean(ThetaS(:,i)-ThetaC(:,i))/norm(ThetaC(:,i));
%     errorStemp(i)=mean(TempS(:,i)-TempC(:,i))/norm(ThetaC(:,i));
% end   
% hold on
% plot([1:4800],errorPtheta,'k')
% plot([1:4800],errorStheta,'k:')
% plot([1:4800],errorPtemp,'r')
% plot([1:4800],errorStemp,'r:')


figure(7)
x0=10;
y0=10;
width=1000;
height=800;
set(gcf,'position',[x0,y0,width,height])

errorPtheta=zeros(4800,1);
errorPtemp=zeros(4800,1);
errorTtheta=zeros(4800,1);
errorTtemp=zeros(4800,1);
errorStheta=zeros(4800,1);
errorStemp=zeros(4800,1);
for i=1:4800
    errorTtheta(i)=norm(ThetaC(:,i)-ThetaT(:,i),1)/norm(ThetaC(:,i),1);
    errorTtemp(i)=norm(TempC(:,i)-TempT(:,i),1)/norm(TempC(:,i),1);
    errorPtheta(i)=norm(ThetaC(:,i)-ThetaP(:,i),1)/norm(ThetaC(:,i),1);
    errorPtemp(i)=norm(TempC(:,i)-TempP(:,i),1)/norm(TempC(:,i),1);
    errorStheta(i)=norm(ThetaC(:,i)-ThetaS(:,i),1)/norm(ThetaC(:,i),1);
    errorStemp(i)=norm(TempC(:,i)-TempS(:,i),1)/norm(ThetaC(:,i),1);
end
hold on
plot([1:4800],errorTtheta,'-','color',[130,200,210]./255,'linewidth',3)
plot([1:4800],errorPtheta,'-','color',[10,130,130]./255,'linewidth',3)
plot([1:4800],errorStheta,'-','color',[50,50,250]./255,'linewidth',3)
plot([1:4800],errorTtemp,':','color',[130,200,210]./255,'linewidth',3)
plot([1:4800],errorPtemp,':','color',[10,130,130]./255,'linewidth',3)
plot([1:4800],errorStemp,':','color',[50,50,250]./255,'linewidth',3)
%legend('water content M_{I}','water content M_{II}','water content M_{R}','temperature M_{I}','temperature M_{II}','temperature M_{R}')
ylabel('RME with respect to M_{full}')
xlabel('Time (h)')
set(gca,'fontname','Times New Roman','fontsize',24)
set(get(gca,'xlabel'),'fontname','Times New Roman','fontsize',24)
set(get(gca,'ylabel'),'fontname','Times New Roman','fontsize',24)
yticks([0:0.01:0.1])
axis([0,4800,0,0.1])
box on

figure(9)
x0=10;
y0=10;
width=400;
height=300;
set(gcf,'position',[x0,y0,width,height])
hold on
plot([4400:4800],errorPtheta(4400:4800),'-','color',[10,130,130]./255,'linewidth',3)
plot([4400:4800],errorStheta(4400:4800),'-','color',[50,50,250]./255,'linewidth',3)
plot([4400:4800],errorPtemp(4400:4800),':','color',[10,130,130]./255,'linewidth',3)
plot([4400:4800],errorStemp(4400:4800),':','color',[50,50,250]./255,'linewidth',3)
set(gca,'fontname','Times New Roman','fontsize',20)
set(get(gca,'xlabel'),'fontname','Times New Roman','fontsize',20)
set(get(gca,'ylabel'),'fontname','Times New Roman','fontsize',20)
axis([4400,4800,0,0.0004])
box on