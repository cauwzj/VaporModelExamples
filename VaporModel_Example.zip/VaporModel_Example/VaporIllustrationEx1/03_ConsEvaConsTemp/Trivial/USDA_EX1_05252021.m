% USDA example 1
% constant temperature (may need to low the water content)

clear all
close all
clc

H=50; % unit cm
T=200*24*3600; % the input is "day", but the 
nh=100; % number of spatial nodes
dt_0=1; % unit of second
dt_max=60;

c_l=4.187;      %"J g^-1 K-1"
rho_l=1.000;    % g cm^-3
T_0=25;          % oC

dh=H/nh;
dt=dt_0;
TotalT=0;
epsilon=0.0001;
theta_ini=0.20;
tmpr_ini=25;

Head=zeros(nh+1,1); % from bottom to top
Temp=zeros(nh+1,1);
Theta=zeros(nh+1,1);

% assume boundary conditions
TLeft=25;
TRight=30;
HLeft=-9.274162934176326e+03;
HRight=-8.570390159801457e+05;
q_eva=1e-7;    % cm/s

% install the intial condition

SaveThreshold=3600;
TSindex=1;

for i=2:nh
    Head(i,1)=FunWrc(theta_ini,tmpr_ini,2);
    Temp(i,1)=tmpr_ini;
    Theta(i,1)=theta_ini;
end
Temp(1,1)=TLeft;     Theta(1,1)=theta_ini;    Head(1,1)=FunWrc(theta_ini,TLeft,2);
Temp(nh+1,1)=TRight; Theta(nh+1,1)=theta_ini; Head(nh+1,1)=FunWrc(theta_ini,TRight,2);
% begin the time domain iteration, Total time is the stop citerion
while TotalT<T
% ---------------------------------------------------------------------------------------------------    
% firs the water equation     
    
    p=0;
    A=sparse(nh+1,nh+1);
    B=zeros(nh+1,1);
    r=dt/dh/dh;
    
    for i=2:nh
        
    % Hydraulic Equation
    % Coefficient
    A(i,i-1)=-r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i-1),Temp(i-1))));
    A(i,i+1)=-r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i+1),Temp(i+1))));
    A(i,i)=r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i-1),Temp(i-1))))...
        +r.*abs(sqrt(FunKml(Head(i),Temp(i)).*FunKml(Head(i+1),Temp(i+1))))...
        +FunWaCapa(Head(i),Temp(i),1);
    % RHS vector
    B(i,1)=FunWaCapa(Head(i),Temp(i),1).*Head(i);

    end
    
    A(1,1)=1;
    B(1,1)=HLeft;
               
    % up
    A(nh+1,nh)=-r.*abs(sqrt(FunKml(Head(nh+1),Temp(nh+1)).*FunKml(Head(nh),Temp(nh))));
    A(nh+1,nh+1)=r.*abs(sqrt(FunKml(Head(nh+1),Temp(nh+1)).*FunKml(Head(nh),Temp(nh))))...
        +FunWaCapa(Head(nh+1),Temp(nh+1),1);   
    B(nh+1)=FunWaCapa(Head(nh+1),Temp(nh+1),1).*Head(nh+1)-dt/dh*q_eva;

    % solve the equation
    KK=A\B;
    
    Headtt=KK;
    for i=1:nh+1
        if Headtt(i)>-13.0
            Headtt(i)=-13.0;
        end
    end
    
    while p<5
        p=p+1;
        A=sparse(nh+1,nh+1);
        B=zeros(nh+1,1);
        r=dt/dh/dh;
        Headt=Headtt;
        
        for i=2:nh
        % Hydraulic Equation
        % Coefficient
        A(i,i-1)=-r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1))));
        A(i,i+1)=-r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1))));
        A(i,i)=r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1))))...
            +r.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1))))...
            +FunWaCapa(Headt(i),Temp(i),1);
        % RHS vector
        B(i,1)=FunWaCapa(Headt(i),Temp(i),1).*Head(i);
        end
    
        A(1,1)=1;
        B(1,1)=HLeft;
        
            % up
            A(nh+1,nh)=-r.*abs(sqrt(FunKml(Headt(nh+1),Temp(nh+1)).*FunKml(Headt(nh),Temp(nh))));
            A(nh+1,nh+1)=r.*abs(sqrt(FunKml(Headt(nh+1),Temp(nh+1)).*FunKml(Headt(nh),Temp(nh))))...
                +FunWaCapa(Headt(nh+1),Temp(nh+1),1);   
            B(nh+1)=FunWaCapa(Headt(nh+1),Temp(nh+1),1).*Head(nh+1)-dt/dh*q_eva;

        % solve the equation
        KK=A\B;
       
        Headtt=KK;
        for i=1:nh+1
          if Headtt(i)>-13.0
             Headtt(i)=-13.0;
          end
        end
        
        max1=max(abs(Headtt-Headt)./max(abs(Headt)));
        max2=0.0;
       
        if (max(max1,max2)<epsilon)
            p=6;
            Headt=Headtt;
            WaterFail=0;
        end
        
        if p==5
            dt=dt/2;
            WaterFail=1;
        end 
       
    end
    
% ---------------------------------------------------------------------------------------------    
% second the heat equation
    
    if WaterFail==0

        p=0;
        A=sparse(nh+1,nh+1);
        B=zeros(nh+1,1);
        r=dt/dh/dh;

        for i=2:nh

        % Heat Equation
        % Coefficient
        A(i,i-1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i-1),Temp(i-1))));
        A(i,i+1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i+1),Temp(i+1))));
        A(i,i)=r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i-1),Temp(i-1))))...
            +r.*abs(sqrt(FunLambda_Bulk(Headt(i),Temp(i)).*FunLambda_Bulk(Headt(i+1),Temp(i+1))))...
            +FunCs(Headt(i),Temp(i));
        
        if Headt(i+1)>Headt(i)
           A(i,i+1)=A(i,i+1)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1)))).*(Headt(i+1)-Headt(i));
        elseif Headt(i+1)<Headt(i)
           A(i,i)=A(i,i)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1)))).*(Headt(i+1)-Headt(i));
        end
        
        if Headt(i)>Headt(i-1)
           A(i,i)=A(i,i)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1)))).*(Headt(i)-Headt(i-1));
        elseif Headt(i)<Headt(i-1)
           A(i,i-1)=A(i,i-1)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1)))).*(Headt(i)-Headt(i-1)); 
        end
        
        
        % RHS vector

        B(i,1)=FunCs(Headt(i),Temp(i)).*Temp(i)...
            -r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i+1),Temp(i+1)))).*(Headt(i+1)-Headt(i)).*T_0...
            +r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Temp(i)).*FunKml(Headt(i-1),Temp(i-1)))).*(Headt(i)-Headt(i-1)).*T_0;

        end

        % embeded BC 
        % bottom
        A(1,1)=1;
        B(1,1)=TLeft;

        % up
        A(nh+1,nh+1)=1;   
        B(nh+1,1)=TRight;

        % solve the equation
        KK=A\B;

        Temptt=KK;
        
        while p<5
            p=p+1;
            A=sparse(nh+1,nh+1);
            B=zeros(nh+1,1);
            r=dt/dh/dh;
            Tempt=Temptt;

            for i=2:nh
                % Heat Equation
                % Coefficient
                A(i,i-1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i-1),Tempt(i-1))));
                A(i,i+1)=-r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i+1),Tempt(i+1))));
                A(i,i)=r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i-1),Tempt(i-1))))...
                    +r.*abs(sqrt(FunLambda_Bulk(Headt(i),Tempt(i)).*FunLambda_Bulk(Headt(i+1),Tempt(i+1))))...
                    +FunCs(Headt(i),Tempt(i));
                % RHS vector
                
                if Headt(i+1)>Headt(i)
                   A(i,i+1)=A(i,i+1)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1)))).*(Headt(i+1)-Headt(i));
                elseif Headt(i+1)<Headt(i)
                   A(i,i)=A(i,i)-r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1)))).*(Headt(i+1)-Headt(i));
                end

                if Headt(i)>Headt(i-1)
                   A(i,i)=A(i,i)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1)))).*(Headt(i)-Headt(i-1));
                elseif Headt(i)<Headt(i-1)
                   A(i,i-1)=A(i,i-1)+r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1)))).*(Headt(i)-Headt(i-1)); 
                end

                B(i,1)=FunCs(Headt(i),Tempt(i)).*Temp(i)...
                    -r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i+1),Tempt(i+1)))).*(Headt(i+1)-Headt(i)).*T_0...
                    +r.*c_l.*rho_l.*abs(sqrt(FunKml(Headt(i),Tempt(i)).*FunKml(Headt(i-1),Tempt(i-1)))).*(Headt(i)-Headt(i-1)).*T_0;

            end

            % embeded BC 
            % bottom
            A(1,1)=1;
            B(1,1)=TLeft;

            % up
            A(nh+1,nh+1)=1;   
            B(nh+1,1)=TRight;

            % solve the equation
            KK=A\B;

            Temptt=KK;

            max1=0.0;
            max2=max(abs(Temptt-Tempt)./max(abs(Tempt)));

            if (max(max1,max2)<epsilon)
                p=6;
                Head=Headt;
                Temp=Temptt;
                TotalT=TotalT+dt;
                dt=min(dt_max,dt*1.5);
            end

            if p==5
                dt=dt/2;
            end 

        end
    end
    
    for i=1:nh+1
        Theta(i,1)=FunWrc(Head(i),Temp(i),1);
    end
    
    if TotalT>SaveThreshold
        ThetaSave(:,TSindex)=Theta;
        HeadSave(:,TSindex)=Head;
        TmprSave(:,TSindex)=Temp;
        SaveThreshold=SaveThreshold+3600;
        TSindex=TSindex+1;
    end
    
end

xlswrite('..\SimuResTrivial.xlsx',ThetaSave,'theta');
xlswrite('..\SimuResTrivial.xlsx',HeadSave,'head');
xlswrite('..\SimuResTrivial.xlsx',TmprSave,'temp');

