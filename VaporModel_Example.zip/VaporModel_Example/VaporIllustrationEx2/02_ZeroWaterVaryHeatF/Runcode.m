
cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\02_ZeroWaterVaryHeatF\Coupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\02_ZeroWaterVaryHeatF\Proposed'
run('USDA_EX1_05252021_Explicit_Tempclose.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\02_ZeroWaterVaryHeatF\SemiCoupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\02_ZeroWaterVaryHeatF\Trivial'
run('USDA_EX1_05252021.m')