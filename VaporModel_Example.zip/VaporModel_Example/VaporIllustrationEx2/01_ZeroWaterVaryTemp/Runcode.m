
cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\01_ZeroWaterVaryTemp\Coupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\01_ZeroWaterVaryTemp\Proposed'
run('USDA_EX1_05252021_Explicit_Tempclose.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\01_ZeroWaterVaryTemp\SemiCoupled'
run('USDA_EX1_05252021_Explicit.m')

cd 'D:\VaporFlowReferenceAndTrial\MatlabPlayCode\IllustrationRelease20210701\VaporIllustrationEx2\01_ZeroWaterVaryTemp\Trivial'
run('USDA_EX1_05252021.m')